'use strict';

function BaseShippingMethodModel() {}

module.exports = BaseShippingMethodModel;
