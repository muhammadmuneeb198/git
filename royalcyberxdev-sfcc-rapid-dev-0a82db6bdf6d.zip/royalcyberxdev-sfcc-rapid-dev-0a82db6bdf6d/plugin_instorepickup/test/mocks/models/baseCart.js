'use strict';

function BaseCartModel() {
}

BaseCartModel.prototype = {
};

module.exports = BaseCartModel;
