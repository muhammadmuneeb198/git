'use strict';

function BaseOrderLineModel() {
}

BaseOrderLineModel.prototype = {
};

module.exports = BaseOrderLineModel;
