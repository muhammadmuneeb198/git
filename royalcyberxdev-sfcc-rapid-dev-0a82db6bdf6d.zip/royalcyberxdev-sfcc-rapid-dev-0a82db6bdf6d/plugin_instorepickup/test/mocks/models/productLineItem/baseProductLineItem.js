'use strict';

function BaseProductLineModel() {
}

BaseProductLineModel.prototype = {
};

module.exports = BaseProductLineModel;
