'use strict';

var base = module.superModule;
base['3'] = 'GiftRegistry-AddProductIntercept';
base['4'] = 'GiftRegistry-Manage';
base['5'] = 'GiftRegistry-Begin';
module.exports = base;
