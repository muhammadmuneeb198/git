'use strict';

function BaseProductLineItemModel() {
}

BaseProductLineItemModel.prototype = {
};

module.exports = BaseProductLineItemModel;
