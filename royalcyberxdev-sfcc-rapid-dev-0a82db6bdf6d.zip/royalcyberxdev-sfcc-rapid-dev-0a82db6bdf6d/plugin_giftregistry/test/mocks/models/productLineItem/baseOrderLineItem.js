'use strict';

function BaseOrderLineItemModel() {
}

BaseOrderLineItemModel.prototype = {
};

module.exports = BaseOrderLineItemModel;
