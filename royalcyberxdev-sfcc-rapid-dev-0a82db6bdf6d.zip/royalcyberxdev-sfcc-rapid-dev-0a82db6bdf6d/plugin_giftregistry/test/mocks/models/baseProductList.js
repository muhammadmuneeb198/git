'use strict';

function BaseProductListModel() {
    this.productList = {};
}

BaseProductListModel.prototype = {
};

module.exports = BaseProductListModel;
