'use strict';

function productListItem() {
    this.productListItem = {

    };
}

productListItem.prototype = {};

module.exports = productListItem;
