'use strict';

var BaseCartHelpers = {
    getQtyAlreadyInCart: function () { return 1; },
    hasSameOptions: function () { return true; },
    getExistingProductLineItemsInCart: function () { return []; },
    allBundleItemsSame: function () { return; }
};

module.exports = BaseCartHelpers;
